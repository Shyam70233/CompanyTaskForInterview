<?php 
include("core.php");
checkLogin();
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Bootstrap Example</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
	<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body>
	<div class="container">

		<nav class="navbar navbar-expand-sm bg-dark navbar-dark">

			<ul class="navbar-nav">
				<li class="nav-item">
					<a class="nav-link" href="#">Welcome : <?php echo $_SESSION['name']; ?></a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="logout.php">Logout</a>
				</li>
			</ul>
		</nav>
		<br>
		<h3>Basic Navbar Example</h3>
		
		<div class="row">
			<div class="col-md-12 form-group">
				<label>Textarea</label>
				<textarea class="form-control" id="teaxdata" name="teaxdata"></textarea>
				<span id="name-error"></span>
			</div>
			<div class="col-md-12 form-group">
				<button class="btn btn-primary" id="submit" name="submit">Click me</button>
			</div>
		</div>

		<div class="row">
			<div class="col-md-12 form-group ">
				<div id="tableData">
					
				</div>
			</div>
		</div>
	</div>

	<script>
$(document).ready(function(){
	function showData(){
		var showDataRes = "showDataRes";
		$.ajax({
			url:"data-ajax.php",
			method:"post",
			data:{showDataRes:showDataRes},
			success:function(data){
				$("#tableData").html(data)
			}
		});
	}
	showData();

	$("#submit").on('click',function(e){
		e.preventDefault();
		var txtData = $("#teaxdata").val();
		var insertData = "insertData";
		if(txtData == ""){
			$("#name-error").html('<p class="text-danger">feilds are Required.</p>');
		}
		else{
			$.ajax({
				url:"data-ajax.php",
				method:'post',
				data:{txtData:txtData,insertData:insertData},
				success:function(data){
					if(data == 1){
						$('textarea').val('');
						$("#name-error").hide();
						showData();
					}else{
						alert("Somthing wenst to wrong ");
					}
				}
			})
		}
	});
});

	</script>

</body>
</html>
