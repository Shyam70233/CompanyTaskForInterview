<?php 
include("core.php");
	$resQuery=result("select * from posts INNER JOIN users ON users.id=posts.uid order by posts.pid desc");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
 
<div class="container">
  <h2>All Posts</h2>
  <?php
  if($resQuery !=null){
  	foreach ($resQuery as  $value) {
  ?>
  <div class="card" >
    <div class="card-body w-100">
      <h4 class="card-title">Post By : <?php echo $value['name']; ?></h4>
      <p class="card-text"><?php echo $value['body']; ?></p>
      <!-- <p>Post Date : <?php // echo date('d-m-Y', strtotime($value['createdOn'])) ?></p> -->
      <p><strong>Post Date : <?php echo $value['createdOn']; ?></strong></p>
     
    </div>
  </div>
  <br>
<?php } } else { ?>

	<div class="card" >
    <div class="card-body w-100">
      <h4 class="card-title">Sorry No Post</h4>
      
    </div>
  </div>
  <br>

<?php } ?>
</div>

</body>
</html>
