<?php 
include("core.php");
session_destroy();
loc("index.php");
?>