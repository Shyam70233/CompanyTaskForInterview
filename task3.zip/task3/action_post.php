<?php 
include("core.php");
$con=con();
if(isset($_POST['submit'])){
	$name = mysqli_real_escape_string ($con, $_POST['name']);
	$email = mysqli_real_escape_string ($con, $_POST['email']);
	$password = mysqli_real_escape_string ($con, $_POST['password-field']);
	$pass = password_hash($password, PASSWORD_DEFAULT);
	if($res = insert( "INSERT INTO `users`(`name`, `email`, `password`) VALUES ('$name','$email','$pass') ")){
		loc("index.php");
	}else{
		alert("Something Wents to wrong");
	}
}

?>