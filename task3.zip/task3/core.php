<?php 
session_start();

function con(){
	$con = mysqli_connect("localhost","root","","mantis1");
	if($con->connect_error){
		die("Connection Failed".$con->connect_error);
	}
	return $con;
}
// echo "Connection Successfully";

function insert($sql)
{
	$con=con();
	$result=mysqli_query($con,$sql);
	return $result;
}

function result($sql)
{
	$con=con();
	$result=mysqli_query($con,$sql);
	$a=[];
	while($row=mysqli_fetch_assoc($result))
	{
		array_push($a, $row);
	}
	return $a;
}

function loc($a){
	echo "<script>window.location.assign('$a')</script>";
}


function alert($a){
	echo "<script>alert('$a')</script>";
}

function checkLogin(){
	if(!isset($_SESSION['id'])){
		// session_destroy();
		alert("Sorry direct access not allows this program ");
		loc("index.php");

	}
}

?>