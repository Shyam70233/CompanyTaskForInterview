<?php 
include("core.php");
checkLogin();
$sid = $_SESSION['id'];
if(isset($_POST['insertData'])){
	$name = $_POST['txtData'];
	if(insert("INSERT INTO `posts`(`uid`,`body`) VALUES ('$sid','$name') ")){
		echo 1;
	}else{
		echo 0;
	}
}
elseif(isset($_POST['showDataRes'])){
	$resQuery=result("select * from posts WHERE uid='$sid' order by pid desc limit 1");	
	$res = @$resQuery[0];
	if($res > 0) {
		$output = $res['body'];
		echo "<p>".$output."</p>";
	}else{
		echo "Sorry Not Data";
	}
}

?>